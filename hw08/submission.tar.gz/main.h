#ifndef MAIN_H
#define MAIN_H

#include "gba.h"

// TODO: Create any necessary structs



struct pacData {
  int x;
  int y;
};





#endif
