/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 pac pacman.png 
 * Time-stamp: Saturday 04/03/2021, 07:44:34
 * 
 * Image Information
 * -----------------
 * pacman.png 25@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PAC_H
#define PAC_H

extern const unsigned short pacman[625];
#define PACMAN_SIZE 1250
#define PACMAN_LENGTH 625
#define PACMAN_WIDTH 25
#define PACMAN_HEIGHT 25

#endif

