/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=40x40 cube glowcube.png 
 * Time-stamp: Saturday 04/03/2021, 06:59:34
 * 
 * Image Information
 * -----------------
 * glowcube.png 40@40
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CUBE_H
#define CUBE_H

extern const unsigned short glowcube[1600];
#define GLOWCUBE_SIZE 3200
#define GLOWCUBE_LENGTH 1600
#define GLOWCUBE_WIDTH 40
#define GLOWCUBE_HEIGHT 40

#endif

