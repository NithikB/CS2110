This program is a simple pacman-like game where the user must move the pacman to reach a target.
Press Enter to start the game, and Backspace at any time to restart.
Use the arrow keys to move the pacman towards the glowstone cube to win the game.